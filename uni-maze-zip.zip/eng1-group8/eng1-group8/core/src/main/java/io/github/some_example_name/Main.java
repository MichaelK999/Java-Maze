package io.github.some_example_name;

import java.security.Key;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import io.github.some_example_name.World;

/**
 * {@link com.badlogic.gdx.ApplicationListener} implementation shared by all
 * platforms.
 */
public class Main extends ApplicationAdapter {
    private SpriteBatch batch;
    private ShapeRenderer shapeRenderer;
    private ScreenViewport viewport;

    private int worldWidth;
    private int worldHeight;

    private World world;

    // LibGDX method for initializing the application
    @Override
    public void create() {
        worldWidth = 16;
        worldHeight = 10;

        batch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();

        world = new World("Maze.csv");

        viewport = new ScreenViewport();
    }

    // LibGDX method for handling window resizing
    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    // libGTX calls this render method every frame
    // A good reminder for methods to see whether they come from LibGTX or you are making yourself
    // is whether they have the @Override method. Same in Minecraft development when you Ovverride stuff like
    // onPlayerJoin etc, because it comes with the game itself
    @Override
    public void render() {
        input();
        logic();
        draw();
    }

    /**
     * Handles user input processing.
     * Currently not implemented - input is handled in the logic() method.
     */
    public void input() {

    }

    /**
     * Updates the game logic each frame.
     * Processes keyboard input for player movement:
     * - Arrow keys (UP, DOWN, LEFT, RIGHT) move the player in the corresponding direction
     * Delegates movement to the world's movePlayer method.
     */
    public void logic() {
        if (Gdx.input.isKeyJustPressed(Keys.RIGHT)) {
            world.movePlayer(1, 0);
        }
        if (Gdx.input.isKeyJustPressed(Keys.LEFT)) {
            world.movePlayer(-1, 0);
        }
        if (Gdx.input.isKeyJustPressed(Keys.UP)) {
            world.movePlayer(0, 1);
        }
        if (Gdx.input.isKeyJustPressed(Keys.DOWN)) {
            world.movePlayer(0, -1);
        }
    }

    /**
     * Renders all game graphics to the screen.
     * Clears the screen to black, applies the viewport, then draws the maze and player.
     * Called every frame as part of the render loop.
     */
    public void draw() {
        ScreenUtils.clear(Color.BLACK);
        viewport.apply();
        

        // So every frame we draw the maze and the player

        // Draw the maze
        drawMaze();
        
        // Draw the player as a white square
        drawPlayer();
    }
    
    /**
     * Renders the maze to the screen.
     * Calculates tile dimensions to fill the screen and draws each tile with appropriate colors:
     * - White for walls (tile type 1)
     * - Dark gray for paths (tile type 0)
     * - Red for unknown tile types
     * Uses the ShapeRenderer to draw filled rectangles for each tile.
     */
    private void drawMaze() {
        int[][] maze = world.getMazeArray();
        shapeRenderer.setProjectionMatrix(viewport.getCamera().combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        
        // Calculate tile size to fill the screen
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / maze[0].length;
        float tileHeight = screenHeight / maze.length;
        
        for (int row = 0; row < maze.length; row++) {
            for (int col = 0; col < maze[row].length; col++) {
                int tileType = maze[row][col];
                
                // Set color based on tile type
                if (tileType == 1) {
                    shapeRenderer.setColor(Color.WHITE); // Walls
                } else if (tileType == 0) {
                    shapeRenderer.setColor(Color.DARK_GRAY); // Paths
                } else {
                    shapeRenderer.setColor(Color.RED); // Unknown tiles
                }
                
                // Draw the tile (scaled to fill screen)
                shapeRenderer.rect(col * tileWidth, row * tileHeight, tileWidth, tileHeight);
            }
        }
        
        shapeRenderer.end();
    }
    
    /**
     * Renders the player character to the screen.
     * Calculates the player's position based on tile dimensions and draws a white square
     * at the player's current position in the world.
     * The player size matches the maze tile dimensions for proper scaling.
     */
    private void drawPlayer() {
        int[][] maze = world.getMazeArray();
        shapeRenderer.setProjectionMatrix(viewport.getCamera().combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        
        // Calculate tile size to match maze tiles
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / maze[0].length;
        float tileHeight = screenHeight / maze.length;
        
        // Draw player as a white square
        shapeRenderer.setColor(Color.WHITE);
        shapeRenderer.rect(world.getPlayerPos().x * tileWidth, 
                          world.getPlayerPos().y * tileHeight, 
                          tileWidth, tileHeight);
        
        shapeRenderer.end();
    }

    // LibGDX method for cleanup when application closes
    @Override
    public void dispose() {
        batch.dispose();
        shapeRenderer.dispose();
    }
}
