package io.github.some_example_name;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.math.Vector2;

public class World {
    private Vector2 playerPos;

    private int[][] mapArray;

    public World(String MazeFilePath) {
        this.playerPos = new Vector2(0, 0);
        this.mapArray = parseMaze(MazeFilePath);
    }

    // CSV parser that now fills the Tile array, for now it simply fills a int array
    // with the int values of the result of the CSV,
    // it is able to be changed to either fill the array with tile obejcts or a
    // tuple depending on what we decide
    public int[][] parseMaze(String mazeFilePath) {
        List<String[]> rows = new ArrayList<>();

        try {
            String line;

            FileHandle file = Gdx.files.internal(mazeFilePath);

            BufferedReader br = new BufferedReader(new InputStreamReader(file.read()));

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty())
                    continue; // skip empty lines
                rows.add(line.split(","));
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
            return new int[0][0];
        }

        if (rows.isEmpty()) // Just incase the csv given is empty
            return new int[0][0];

        int numRows = rows.size();
        int numCols = rows.get(0).length;

        int[][] maze = new int[numRows][numCols];

        for (int r = 0; r < numRows; r++) {
            String[] row = rows.get(numRows - 1 - r);

            for (int c = 0; c < numCols; c++) {
                int value = Integer.parseInt(row[c].trim());

                // For now it simply fills the array with the int
                maze[r][c] = value;

                // ============================
                // PLACEHOLDER FOR TILE LOGIC
                // ----------------------------
                // In the future, instead of:
                // maze[r][c] = value;
                //
                // You might do something like:
                // if (value == 1)
                // maze[r][c] = new WallTile();
                // else if (value == -1)
                // maze[r][c] = new PathTile();
                // else
                // maze[r][c] = new EmptyTile();
                //
                // (and change maze[][] to a Tile[][])
                // ============================
            }
        }

        return maze;
    }

    public Vector2 getPlayerPos() {
        return this.playerPos;
    }

    public int[][] getMazeArray() {
        return this.mapArray;
    }
    
    public void movePlayer(int deltaX, int deltaY) {
        int newX = (int) (playerPos.x + deltaX);
        int newY = (int) (playerPos.y + deltaY);
        
        // Check bounds
        if (newX >= 0 && newX < mapArray[0].length && 
            newY >= 0 && newY < mapArray.length) {
            // Check if the new position is not a wall (tile type 1)
            if (mapArray[newY][newX] != 1) {
                playerPos.x = newX;
                playerPos.y = newY;
            }
        }
    }
}
