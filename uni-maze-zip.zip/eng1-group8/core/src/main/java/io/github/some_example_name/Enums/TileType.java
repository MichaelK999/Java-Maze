package io.github.some_example_name.Enums;

/**
 * Enumeration of tile types used in the game map.
 *
 * <p>Each {@code TileType} represents a category for a map tile.
 *
 * <p>This enum is intentionally simple; any additional per-type data or behavior
 * should be handled by associated systems.
 */
public enum TileType {
    /**
     * A normal path tile that entities can walk on used to build routes through the map.
     */
    PATH,

    /**
     * An impassable wall tile. Movement into this tile should be blocked by the
     * collision or pathfinding logic.
     */
    WALL,

    /**
     * A tile that grants a chance-based reward or event when interacted with.
     */
    LUCKYTILE,

    /**
     * The exit tile that typically marks level completion or an exit point. Stepping
     * on this tile usually triggers a transition to the victory state.
     */
    EXITTILE,

    /**
     * A tile intended to create a scary or surprising effect.
     */
    SCARYTILE,

    /**
     * A tile that spawns the enemy.
     */
    ENEMYTILE
}
