// filepath: c:\Users\benbu\Desktop\WORk\eng1-group8\core\src\main\java\io\github\some_example_name\World.java
package io.github.some_example_name;

import java.beans.Visibility;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Vector2;

import io.github.some_example_name.Enums.State;
import io.github.some_example_name.Enums.TileAction;
import io.github.some_example_name.Enums.TileType;
import io.github.some_example_name.Tiles.Tile;

/**
 * Represents the game world / level state loaded from a maze file.
 *
 * <p>The World class is responsible for:
 * - Loading a tile-based maze from a CSV file (via {@link #parseMaze(String)}).
 * - Tracking the player's position and movement.
 * - Managing tile actions (e.g., victory, jumpscare, gamble, spawn enemy).
 * - Managing fog-of-war visibility via a simple visibility map and flood-fill
 *   style expansion (see {@link #initializeFog()} and {@link #updateVisibilty(int,int)}).
 * - Maintaining game-wide state such as time remaining, score, current game state,
 *   and the set of active enemies.
 *
 * <p>Game systems (rendering, input, main loop) should call {@link #updateGame()}
 * each frame to update time and enemies, and {@link #movePlayer(int,int)} to move
 * the player. UI interactions are performed through the {@link I_UI} reference
 * supplied to the constructor.
 */
public class World {
    /**
     * The player's position in tile coordinates (x = column, y = row).
     * Uses a {@link Vector2} for convenience; integer values are stored in the x/y components.
     */
    private Vector2 playerPos;

    /** 2D array of tiles representing the map: indexed by [row][col]. */
    private Tile[][] tileMap;
    /** Number of columns (width) in the loaded map. */
    private int mapWidth;
    /** Number of rows (height) in the loaded map. */
    private  int mapHeight;

    /** Reference to the UI controller used to display timed overlays. */
    private I_UI uiControls;

    /** Time left in the level (in seconds). */
    private float timeLeft;
    /** Current high-level game state (MENU, PLAYING, VICTORY, GAMEOVER, etc.). */
    private State currentState;
    /** Player's accumulated score. */
    private int finalScore;

    // Fog attributes

    /** Whether fog-of-war is currently active. */
    private boolean fogActive;
    /**
     * Per-tile visibility values. Convention used in this code:
     * - 1.0f = fully dark/unseen
     * - 0.5f = partially visible (nearby)
     * - 0.0f = fully revealed/visible
     *
     * Indexed by [row][col] (same dimensions as tileMap).
     */
    private float[][] visibilityMap;

    /** Active enemies present in the world. Enemies follow breadcrumbs and can catch the player. */
    private List<Enemy> enemies;

    /**
     * Construct a World instance by loading a maze file and initializing state.
     *
     * @param mazeFilePath path (internal file handle) to the CSV maze definition
     * @param uiControls UI controller used for displaying overlays and UI interactions
     */
    public World(String mazeFilePath, I_UI uiControls) {
        playerPos = new Vector2(0, 0);

        currentState = State.MENU;  // Start at menu/reset screen

        timeLeft = 300f;
        finalScore = 0;

        this.uiControls = uiControls;

        // Initialize enemy system - start with empty list
        enemies = new ArrayList<>();

        this.tileMap = parseMaze(mazeFilePath);

        visibilityMap = new float[mapHeight][mapWidth];

        initializeFog();
    }

    /**
     * Initialize fog-of-war state.
     *
     * Sets all tiles to fully dark (1.0f) then reveals the exit tile and the
     * player's starting position by calling {@link #updateVisibilty(int,int)}.
     */
    private void initializeFog(){
        fogActive = true;

        for (int y = 0; y < mapHeight; y++) {
            for (int x = 0; x < mapWidth; x++) {
                visibilityMap[y][x] = 1.0f; // fully dark
            }
        }
        for (int y = 0; y < mapHeight; y++) {
            for (int x = 0; x < mapWidth; x++) {
                if (tileMap[y][x].getType() == TileType.EXITTILE){
                    updateVisibilty(x, y);
                }
            }
        }

        updateVisibilty((int) playerPos.x, (int) playerPos.y);
    }

    /**
     * Parse a CSV maze file into a 2D {@link Tile} array.
     *
     * CSV format expectations:
     * - Rows separated by newlines, columns separated by commas.
     * - Integer cell values map to tile types:
     *   1 = PATH
     *   2 = EXITTILE (victory)
     *   3 = SCARYTILE (jumpscare)
     *   4 = LUCKYTILE (gamble)
     *   5 = ENEMYTILE (spawn enemy)
     *   6 = PLAYER START (path tile and sets playerPos)
     *   default = WALL
     *
     * The parser reads rows into memory, then flips them vertically so the file's
     * top row becomes the map's highest Y (matching a usual screen coordinate layout).
     *
     * @param mazeFilePath internal path to the maze CSV file
     * @return a 2D Tile array indexed as [row][col]; empty array on IO errors
     */
    public Tile[][] parseMaze(String mazeFilePath) {
        List<String[]> rows = new ArrayList<>();

        try {
            String line;

            FileHandle file = Gdx.files.internal(mazeFilePath);

            BufferedReader br = new BufferedReader(new InputStreamReader(file.read()));

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty())
                    continue; // skip empty lines
                rows.add(line.split(","));
            }
            br.close();
        } catch (IOException e) {
            return new Tile[0][0];
        }

        if (rows.isEmpty()) { // Just incase the csv given is empty
            return new Tile[0][0];
        }

        this.mapHeight = rows.size();
        this.mapWidth = rows.get(0).length;

        Tile[][] maze = new Tile[mapHeight][mapWidth];

        for (int r = 0; r < mapHeight; r++) {
            String[] row = rows.get(mapHeight - 1 - r);

            for (int c = 0; c < mapWidth; c++) {
                int value = Integer.parseInt(row[c].trim());

                switch (value) {
                    case 1:
                        maze[r][c] = new Tile(
                            TileType.PATH ,
                            "Tiles/Path.png",
                            true);
                        break;
                    case 2:
                        maze[r][c] = new Tile(
                            TileType.EXITTILE,
                            "Tiles/Victory.png",
                            true,
                            TileAction.VICTORY);
                        break;
                    case 3:
                        maze[r][c] = new Tile(
                            TileType.SCARYTILE,
                            "Tiles/Path.png",
                            true,
                            TileAction.JUMPSCARE);
                        break;
                    case 4:
                        maze[r][c] = new Tile(
                            TileType.LUCKYTILE,
                            "Tiles/GambleTile.png",
                            true,
                            TileAction.GAMBLE);
                        break;
                    case 5:
                        maze[r][c] = new Tile(
                            TileType.ENEMYTILE,
                            "Tiles/EnemyTile.png",
                            true,
                            TileAction.SPAWN_ENEMY);
                        break;
                    case 6:
                        maze[r][c] = new Tile(
                            TileType.PATH,
                            "Tiles/Path.png",
                            true);

                        this.playerPos.x = c;
                        this.playerPos.y = r;
                        break;
                    default:
                        maze[r][c] = new Tile(
                            TileType.WALL,
                            "Tiles/Wall.png",
                            false);
                        break;
                }
                maze[r][c].setPosition(c, r);
            }
        }

        return maze;
    }

    /**
     * Get the player's current tile position.
     *
     * @return a {@link Vector2} with integer-valued x and y representing tile coords
     */
    public Vector2 getPlayerPos() {
        return this.playerPos;
    }

    /**
     * Access the tile map for rendering or logic queries.
     *
     * @return 2D array of {@link Tile} indexed by [row][col]
     */
    public Tile[][] getTileMap() {
        return this.tileMap;
    }

    /**
     * Execute the provided {@link TileAction} for a given tile.
     *
     * @param action the action to perform
     * @param tile the tile that triggered the action (can be null for some actions)
     */
    public void doAction(TileAction action, Tile tile) {

        switch (action) {
            case VICTORY:
                currentState = State.VICTORY;
                addScore((int) this.timeLeft);
                break;
            case JUMPSCARE:
                uiControls.displayUI(new TimedOverlay("UI/bob.png", 5, true, 1));
                break;
            case GAMBLE:
                uiControls.displayUI(new TimedOverlay("UI/Gamble.png", 1.5f, true, 0.9f, 400, 400));
                handleGamble();
                break;
            case ADDSCORE:
                uiControls.displayUI(new TimedOverlay("UI/ScoreIncrease.png", 1.5f, true, 0.9f, 400, 400));
                Random random = new Random();

                int roll = random.nextInt(3); // gives 0, 1, or 2

                if (roll == 0) {
                    addScore(25);
                    System.out.println("+25");
                } else if (roll == 1) {
                    addScore(50);
                    System.out.println("+50");
                } else {
                    addScore(100);
                    System.out.println("+100");
                }

                break;
            case SPAWN_ENEMY:
                // Spawn enemy at the tile where player just stepped
                Enemy newEnemy = new Enemy();
                newEnemy.spawn(tile);
                enemies.add(newEnemy);
                break;
            case  REVEAL_MAP:
                fogActive = false;
                visibilityMap = new float[mapHeight][mapWidth];
                break;
            case  HIDE_MAP:
                initializeFog();
                break;
        }
    }

    /**
     * Replace the specified tile with a normal path tile.
     *
     * This is used to prevent repeated triggering of one-time tile actions after
     * they have been activated.
     *
     * @param oldTile the tile to remove/replace
     */
    private void removeTile(Tile oldTile) {
        tileMap[(int) oldTile.getTilePos().y][(int) oldTile.getTilePos().x] = new Tile(
            TileType.PATH,
            "Tiles/Path.png",
            true);
    }

    /**
     * Handle gamble outcomes by choosing one of the possible {@link TileAction}s
     * and executing it.
     *
     * This method currently picks uniformly at random from a small set and calls
     * {@link #doAction(TileAction, Tile)} with the chosen outcome.
     */
    private void handleGamble() {
        TileAction[] possibleOutcomes = {
            TileAction.ADDSCORE,
            TileAction.REVEAL_MAP
        };

        int index = (int) (Math.random() * possibleOutcomes.length);
        TileAction chosen = possibleOutcomes[index];

        doAction(chosen, null);
    }

    /**
     * Attempt to move the player by (deltaX, deltaY) in tile coordinates.
     *
     * <p>This method:
     * - Validates bounds
     * - Checks traversability (e.g., not a wall)
     * - Updates player position
     * - Appends a breadcrumb for each enemy so they can follow the player
     * - Updates fog visibility if active
     * - Triggers and removes any actions present on the new tile
     *
     * @param deltaX horizontal movement in tiles (positive = right)
     * @param deltaY vertical movement in tiles (positive = up)
     */
    public void movePlayer(int deltaX, int deltaY) {
        int newX = (int) (playerPos.x + deltaX);
        int newY = (int) (playerPos.y + deltaY);

        // Check bounds
        if (newX >= 0 && newX < mapWidth &&
            newY >= 0 && newY < mapHeight) {

            Tile newTile = tileMap[newY][newX];

            // Check if the new position is not a wall (tile type 1)
            if (newTile.getTraversability()) {

                // Now move the player
                playerPos.x = newX;
                playerPos.y = newY;

                // Add breadcrumb to ALL spawned enemies
                for (Enemy enemy : enemies) {
                    enemy.addPlayerBreadcrumb(playerPos);
                }

                if (fogActive) {
                    updateVisibilty((int) playerPos.x, (int) playerPos.y);
                }

                if (!(newTile.getActions().isEmpty())) {
                    for (TileAction action : newTile.getActions()) {
                        doAction(action, newTile);
                        removeTile(newTile);
                    }
                }
            }
        }
    }

    /**
     * Update the level timer and set gameover state if time runs out.
     *
     * This method uses LibGDX's {@link Gdx#graphics} delta time.
     */
    private void updateTime() {
        float delta = Gdx.graphics.getDeltaTime();
        timeLeft -= delta;

        if (timeLeft <= 0) {
            this.currentState = State.GAMEOVER;
        }
    }

    /** Get remaining time left in seconds. */
    public float getTime() {
        return this.timeLeft;
    }

    /** Get the current high-level game state. */
    public State getState() {
        return this.currentState;
    }

    /** Set the current high-level game state. */
    public void setState(State state) {
        this.currentState = state;
    }

    /** Increase the player's score by the given amount. */
    public void addScore(int score) {
        finalScore = finalScore + score;
    }

    /** Retrieve the player's current score. */
    public int getScore() {
        return this.finalScore;
    }


    // Getters for Main.java to access enemy data

    /** Get the active enemy list. */
    public List<Enemy> getEnemies() {
        return enemies;
    }

    /** Get the map width in tiles (columns). */
    public int getMapWidth(){
        return this.mapWidth;
    }

    /** Get the map height in tiles (rows). */
    public int getMapHeight(){
        return this.mapHeight;
    }

    /** Whether fog-of-war is currently active. */
    public boolean getFogActive(){
        return this.fogActive;
    }

    /**
     * Update the visibility map starting from a tile position.
     *
     * <p>This uses a localized fill (3x3 neighborhood and near neighbors) to
     * reveal nearby non-wall tiles. It sets the central 3x3 grid to fully visible
     * (0.0f) and adjacent walkable neighbors to partially visible (0.5f) using a flood fill mechanisms.
     *
     * Note: current implementation can "peek" thog corners in rare cases; a
     * more strict visibility algorithm would check orthogonal connectivity.
     *
     * @param startingX starting column (x) in tile coordinates
     * @param startingY starting row (y) in tile coordinates
     */
    private void updateVisibilty(int startingX, int startingY){

        // currently can technically peak through corners but level design prevents this, is ammenedable by checking each corners orthogonal neighboors arnt walls
        // uses flood fill to partially reveal paths players can take

        for (int y = Math.max(0, startingY - 1); y <= Math.min(mapHeight - 1, startingY + 1); y++) {
            for (int x = Math.max(0, startingX - 1); x <= Math.min(mapWidth - 1, startingX + 1); x++) {

                if (tileMap[y][x].getType() != TileType.WALL) {
                    visibilityMap[y][x] = 0.0f;

                    // Check neighbors safely and only update if not already 0
                    if (y > 0 && visibilityMap[y - 1][x] != 0f && tileMap[y - 1][x].getType() != TileType.WALL) {
                        visibilityMap[y - 1][x] = 0.5f; // Up
                    }
                    if (y < mapHeight - 1 && visibilityMap[y + 1][x] != 0f && tileMap[y + 1][x].getType() != TileType.WALL) {
                        visibilityMap[y + 1][x] = 0.5f; // Down
                    }
                    if (x > 0 && visibilityMap[y][x - 1] != 0f && tileMap[y][x - 1].getType() != TileType.WALL) {
                        visibilityMap[y][x - 1] = 0.5f; // Left
                    }
                    if (x < mapWidth - 1 && visibilityMap[y][x + 1] != 0f && tileMap[y][x + 1].getType() != TileType.WALL) {
                        visibilityMap[y][x + 1] = 0.5f; // Right
                    }
                }
            }
        }
    }

    /**
     * Called each frame to update game-level state.
     *
     * <p>This method updates the level timer and then updates each active enemy.
     * If any enemy reports that it has caught the player, the world's state is
     * moved to {@link State#GAMEOVER}.
     */
    public void updateGame() {
        updateTime();

        // Update all enemies and check for collisions
        for (Enemy enemy : enemies) {
            if (enemy.update(playerPos)) {
                currentState = State.GAMEOVER;
                break; // No need to check other enemies if one caught the player
            }
        }
    }

    /** Return the current visibility map used by the renderer to draw fog-of-war. */
    public float[][] getVisibilityMap(){
        return this.visibilityMap;
    }

}
