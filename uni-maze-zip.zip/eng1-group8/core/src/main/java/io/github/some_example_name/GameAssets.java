// filepath: c:\Users\benbu\Desktop\WORk\eng1-group8\core\src\main\java\io\github\some_example_name\GameAssets.java
package io.github.some_example_name;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;

/**
 * Centralized asset manager wrapper for the game.
 *
 * <p>This class implements a simple singleton that encapsulates a LibGDX {@link AssetManager}
 * and provides convenience methods to load and retrieve textures used by the game.
 *
 * Key responsibilities:
 * - Provide a single shared {@link AssetManager} instance via {@link #getInstance()}.
 * - Load the game's primary textures in {@link #loadMainAssets()}.
 * - Provide safe retrieval of assets via {@link #get(String, Class)} which returns a
 *   fallback ("Missing.png") when a requested asset hasn't been loaded.
 * - Allow adding and immediately finishing loading a texture via {@link #addTexture(String)}.
 */
public class GameAssets {
    /**
     * The singleton instance of {@link GameAssets}.
     */
    private static GameAssets instance;

    /**
     * The underlying LibGDX asset manager used to load and retrieve assets.
     */
    private final AssetManager manager;

    /**
     * Private constructor to enforce singleton usage.
     * Initializes the internal {@link AssetManager}.
     */
    private GameAssets() {
        manager = new AssetManager();
    }

    /**
     * Returns the singleton {@link GameAssets} instance, creating it if necessary.
     *
     * @return the single shared {@link GameAssets} instance
     */
    public static GameAssets getInstance() {
        if (instance == null){
            instance = new GameAssets();
        }
        return instance;
    }

    /**
     * Schedule loading of the game's primary textures into the asset manager.
     *
     * <p>This method only queues assets for loading. Call {@link #finishLoading()} to
     * block until the queued assets are loaded.
     *
     * The assets loaded here include:
     * - Sprites (Enemy, Player)
     * - Tile textures (EnemyTile, Fog, GambleTile, Path, Victory, Wall)
     * - UI elements (bob, Gamble)
     * - Screen backgrounds (victory, tutorial, bookshelf)
     * - A fallback texture "Missing.png" used when a requested file isn't loaded
     */
    public void loadMainAssets() {
        // Sprites
        manager.load("Sprites/Enemy.png", Texture.class);
        manager.load("Sprites/Player.png", Texture.class);

        // Tiles
        manager.load("Tiles/EnemyTile.png", Texture.class);
        manager.load("Tiles/Fog.png", Texture.class);
        manager.load("Tiles/GambleTile.png", Texture.class);
        manager.load("Tiles/Path.png", Texture.class);
        manager.load("Tiles/Victory.png", Texture.class);
        manager.load("Tiles/Wall.png", Texture.class);

        //UI
        manager.load("UI/bob.png", Texture.class);
        manager.load("UI/Gamble.png", Texture.class);

        // Screens
        manager.load("Screens/victory.png", Texture.class);
        manager.load("Screens/tutorial.png", Texture.class);
        manager.load("Screens/bookshelf.png", Texture.class);

        // A fallback texture for missing files
        manager.load("Missing.png", Texture.class);
    }

    /**
     * Blocks until all assets currently queued in the {@link AssetManager} are loaded.
     *
     * <p>Call this after {@link #loadMainAssets()} if you want synchronous startup loading.
     */
    public void finishLoading() {
        manager.finishLoading();
    }

    /**
     * Retrieve a loaded asset from the manager.
     *
     * <p>If the requested asset identified by {@code fileName} is loaded, returns it.
     * Otherwise, returns the "Missing.png" fallback texture (cast to {@code type}).
     *
     * @param <T> the type of the asset (e.g. {@link Texture})
     * @param fileName the asset file path/key used with the asset manager
     * @param type the {@link Class} object representing the asset type
     * @return the loaded asset if present; otherwise the "Missing.png" fallback cast to {@code T}
     */
    public <T> T get(String fileName, Class<T> type) {
        if (manager.isLoaded(fileName, type)) {
            return manager.get(fileName, type);
        } else {
            return manager.get("Missing.png", type);
        }
    }

    /**
     * Add a texture to the asset manager and finish loading it synchronously.
     *
     * <p>If the texture is already loaded this method is a no-op. Otherwise it
     * queues the texture for loading and then calls {@link AssetManager#finishLoading()}
     * to block until it is available.
     *
     * @param fileName the file path/key of the texture to add
     */
    public void addTexture(String fileName) {
        // Check if the texture is already loaded
        if (!manager.isLoaded(fileName, Texture.class)) {
            manager.load(fileName, Texture.class);
            manager.finishLoading();
        }
    }

    /**
     * Dispose of the internal {@link AssetManager} and free resources.
     *
     * <p>After calling this method the {@link GameAssets} instance's manager will be disposed
     * and should not be used again. If you need to restart asset loading you should create
     * a new process or modify this class to allow reinitialization.
     */
    public void dispose() {
        manager.dispose();
    }
}
