package io.github.some_example_name.Enums;

/**
 * Actions that a Tile can trigger when a player or entity interacts with it.
 *
 * <p>Each enum constant represents a discrete gameplay effect. Game logic should
 * map these values to concrete behaviors (for example, showing a victory screen
 * for VICTORY or spawning an enemy for SPAWN_ENEMY).
 *
 * <p>These are used by tile-related systems to determine what should happen when
 * a tile is activated or stepped on.
 */
public enum TileAction {
    /** Trigger the game's victory condition (end the level with success). */
    VICTORY,

    /** Play a jumpscare applying any associated effects. */
    JUMPSCARE,

    /** Initiate a gamble interaction (e.g., chance-based reward. */
    GAMBLE,

    /** Add points or score to the player's total. */
    ADDSCORE,

    /** Spawn an enemy at this tile. The spawning system decides specifics. */
    SPAWN_ENEMY,

    /** Reveal the full map. */
    REVEAL_MAP,

    /** Remove all visited areas essentially ressting the players view. */
    HIDE_MAP
}
