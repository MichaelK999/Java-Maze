package io.github.some_example_name.Tiles;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

import io.github.some_example_name.Enums.TileAction;
import io.github.some_example_name.Enums.TileType;
import io.github.some_example_name.GameAssets;

/**
 * Represents a single map tile in the game.
 *
 * A Tile encapsulates:
 * - its logical type ({@link TileType}),
 * - the visual representation as a {@link Texture},
 * - whether it can be traversed by entities,
 * - its position in the map array ({@link Vector2}),
 * - a list of actions/events that are triggered when interacting with the tile.
 *
 * Textures are resolved using the shared {@link GameAssets} asset manager.
 */
public class Tile {

    /**
     * The type of the tile (e.g. wall, floor, victory).
     */
    private TileType type;

    /**
     * Texture used to render this tile within {@link io.github.some_example_name.Main}.
     */
    private Texture tileTexture;

    /**
     * Whether player can walk over / traverse this tile.
     */
    private boolean isTraversable;

    /**
     * Tile position in map-space (x, y).
     * Uses {@link com.badlogic.gdx.math.Vector2} for convenience.
     */
    private Vector2 tilePos;

    /**
     * List of actions associated with the tile. Actions represent gameplay events
     * triggered by stepping on or interacting with the tile.
     */
    private List<TileAction> actions;

    /**
     * Reference to the global asset manager used to fetch textures.
     */
    private GameAssets assetManager;

    /**
     * Create a Tile with the specified type, texture (by file path) and traversability with no actions.
     *
     * @param type             the tile's type
     * @param textureFilePath  key or path used to retrieve the texture from {@link GameAssets}
     * @param walkable         true if this tile can be traversed, false otherwise
     */
    public Tile(TileType type, String textureFilePath, boolean walkable) {

        assetManager = GameAssets.getInstance();

        this.type = type;

        this.tileTexture = assetManager.get(textureFilePath, Texture.class);

        this.isTraversable = walkable;

        tilePos = new Vector2();
        actions = new ArrayList<TileAction>();
    }

    /**
     * Create a Tile with a single associated action/event.
     *
     * @param type             the tile's type
     * @param textureFilePath  key or path used to retrieve the texture from {@link GameAssets}
     * @param walkable         whether the tile can be traversed
     * @param event            a single {@link TileAction} to associate with this tile
     */
    public Tile(TileType type, String textureFilePath, boolean walkable, TileAction event) {

        assetManager = GameAssets.getInstance();

        this.type = type;

        this.tileTexture = assetManager.get(textureFilePath, Texture.class);

        this.isTraversable = walkable;

        tilePos = new Vector2();
        actions = new ArrayList<TileAction>();
        this.actions.add(event);

    }

    /**
     * Create a Tile with multiple associated actions/events.
     *
     * @param type             the tile's type
     * @param textureFilePath  key or path used to retrieve the texture from {@link GameAssets}
     * @param walkable         whether the tile can be traversed
     * @param events           a list of {@link TileAction} to associate with this tileSS
     */
    public Tile(TileType type, String textureFilePath, boolean walkable, List<TileAction> events) {

        assetManager = GameAssets.getInstance();

        this.type = type;

        this.tileTexture = assetManager.get(textureFilePath, Texture.class);

        this.isTraversable = walkable;

        tilePos = new Vector2();
        actions = new ArrayList<TileAction>();
        this.actions.addAll(events);

    }

    /**
     * Returns whether this tile is traversable.
     *
     * @return true if entities can walk over this tile, false otherwise
     */
    public boolean getTraversability() {
        return this.isTraversable;
    }

    /**
     * Returns the texture used to render this tile.
     *
     * @return the {@link Texture} for this tile
     */
    public Texture getTexture() {
        return this.tileTexture;
    }

    /**
     * Set the tile's position in map-space coordinates.*
     * @param x  x coordinate (tile column)
     * @param y  y coordinate (tile row)
     */
    public void setPosition(int x, int y) {
        tilePos.x = x;
        tilePos.y = y;
    }

    /**
     * Returns the tile position as a {@link Vector2}.
     *
     * @return the tile position vector
     */
    public Vector2 getTilePos() {
        return tilePos;
    }

    /**
     * Replace this tile's texture by loading a new texture from the asset manager.
     *
     * @param filepath key or path used to retrieve the new texture from {@link GameAssets}
     */
    public void setTexture(String filepath) {
        this.tileTexture = assetManager.get(filepath, Texture.class);
    }

    /**
     * Returns the {@link TileType} of this tile.
     *
     * @return the tile type
     */
    public TileType getType() {
        return this.type;
    }

    /**
     * Get the list of actions associated with the tile.
     *
     * @return a {@link List} of {@link TileAction} objects attached to this tile
     */
    public List<TileAction> getActions() {
        return actions;
    }
}
