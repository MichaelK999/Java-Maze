package io.github.some_example_name;

import java.util.LinkedList;
import java.util.Queue;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import io.github.some_example_name.Enums.State;
import io.github.some_example_name.Tiles.Tile;

/**
 * {@link com.badlogic.gdx.ApplicationListener} implementation shared by all
 * platforms.
 */
public class Main extends ApplicationAdapter implements I_UI {
    private SpriteBatch batch;
    private ShapeRenderer shapeRenderer;
    private ScreenViewport viewport;
    private BitmapFont font;
    private BitmapFont menuFont;
    private BitmapFont victoryFont;

    private World world;

    private Queue<TimedOverlay> activeOverlays;

    private Texture fogTexture;
    private Texture playerTexture;
    private Texture tutorialTexture;
    private Texture bookshelfTexture;

    // UI components
    private Stage menuStage;
    private Skin skin;
    private Label arrowKeysLabel;
    private Label wasdLabel;

    // Settings
    private boolean useWASD = false; // false = Arrow keys (default), true = WASD

    // singleton asset manager
    private GameAssets assetManager;

    @Override
    public void create() {
        // load assets for project
        assetManager = GameAssets.getInstance();
        assetManager.loadMainAssets();
        assetManager.finishLoading();

        batch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();
        font = new BitmapFont();
        viewport = new ScreenViewport();

        world = new World("Maze.csv",  this);
        activeOverlays = new LinkedList<>();

        fogTexture = assetManager.get("Tiles/Fog.png", Texture.class);
        playerTexture = assetManager.get("Sprites/Player.png", Texture.class);
        tutorialTexture = assetManager.get("Screens/tutorial.png", Texture.class);
        bookshelfTexture = assetManager.get("Screens/bookshelf.png", Texture.class);

        // Load custom Balatro font for menu and victory screens
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("Fonts/balatro.ttf"));

        // Generate menu font (smaller size for UI text)
        FreeTypeFontParameter menuParameter = new FreeTypeFontParameter();
        menuParameter.size = 18; // Font size for menu text
        menuFont = generator.generateFont(menuParameter);

        // Generate victory font (larger size for victory screen)
        FreeTypeFontParameter victoryParameter = new FreeTypeFontParameter();
        victoryParameter.size = 48; // Font size for victory screen
        victoryFont = generator.generateFont(victoryParameter);

        generator.dispose(); // Don't forget to dispose of the generator

        // Create UI
        createSkin();
        menuStage = new Stage(viewport, batch);
        createMenuUI();
    }

    /**
     * Creates the UI skin for menu elements.
     * Sets up default and selected label styles using the Balatro font.
     * Default style uses white text, selected style uses lime/green text.
     */
    private void createSkin() {
        skin = new Skin();
        skin.add("default", menuFont); // Use Balatro font for menu

        // Default label style (white text)
        Label.LabelStyle defaultStyle = new Label.LabelStyle();
        defaultStyle.font = skin.getFont("default");
        defaultStyle.fontColor = Color.WHITE;
        skin.add("default", defaultStyle);

        // Selected label style (green/lime text - highlighted)
        Label.LabelStyle selectedStyle = new Label.LabelStyle();
        selectedStyle.font = skin.getFont("default");
        selectedStyle.fontColor = Color.LIME;
        skin.add("selected", selectedStyle);
    }

    /**
     * Creates the main menu user interface using Scene2D.
     * Builds a layout with instructions, settings controls, and tutorial image.
     * Sets up clickable labels for control scheme selection (Arrow Keys vs WASD).
     */
    private void createMenuUI() {

        // All of this is using Scene2D, LibGTX's UI thing. For example Label is the same as <p> in HTML, table is like flexbox/grid...etc
        Table mainTable = new Table();
        mainTable.setFillParent(true);
        menuStage.addActor(mainTable);

        // Create left side table for text content
        Table leftTable = new Table();

        // === INSTRUCTIONS AT TOP ===
        Label titleLabel = new Label("SPACE to start", skin);
        leftTable.add(titleLabel).padBottom(10).center();
        leftTable.row();

        Label pauseLabel = new Label("During the game, SPACE to pause", skin);
        leftTable.add(pauseLabel).padBottom(10).center();
        leftTable.row();

        Label restartLabel = new Label("During the game, R to restart", skin);
        leftTable.add(restartLabel).padBottom(10).center();
        leftTable.row();

        Label exitLabel = new Label("ESC to exit game", skin);
        leftTable.add(exitLabel).padBottom(40).center();
        leftTable.row();

        // === SETTINGS SECTION ===
        Label settingsLabel = new Label("SETTINGS", skin);
        leftTable.add(settingsLabel).padBottom(20).center();
        leftTable.row();

        // Controller options (horizontal row)
        Table controlsTable = new Table();

        arrowKeysLabel = new Label("ARROW KEYS", skin, "selected");
        arrowKeysLabel.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectArrowKeys();
            }
        });
        controlsTable.add(arrowKeysLabel).padRight(20);

        Label separatorLabel = new Label(" / ", skin);
        controlsTable.add(separatorLabel).padRight(20);

        wasdLabel = new Label("WASD", skin, "default");
        wasdLabel.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectWASD();
            }
        });
        controlsTable.add(wasdLabel);

        leftTable.add(controlsTable).center();
        leftTable.row();

        // Create tutorial image and scale it down to fit nicely
        Image tutorialImage = new Image(tutorialTexture);
        tutorialImage.setScaling(com.badlogic.gdx.utils.Scaling.fit);

        // Add left table and tutorial image to main table (side by side, 50/50 split)
        // Image cell has padding on all sides to prevent cutoff
        mainTable.add(leftTable).width(viewport.getWorldWidth() / 2).pad(20);
        mainTable.add(tutorialImage).width(viewport.getWorldWidth() / 2).right().pad(20, 20, 20, 65);
    }

    /**
     * Switches control scheme to arrow keys.
     * Updates the UI labels to highlight arrow keys as selected.
     */
    private void selectArrowKeys() {
        useWASD = false;
        arrowKeysLabel.setStyle(skin.get("selected", Label.LabelStyle.class));
        wasdLabel.setStyle(skin.get("default", Label.LabelStyle.class));
    }

    /**
     * Switches control scheme to WASD keys.
     * Updates the UI labels to highlight WASD as selected.
     */
    private void selectWASD() {
        useWASD = true;
        wasdLabel.setStyle(skin.get("selected", Label.LabelStyle.class));
        arrowKeysLabel.setStyle(skin.get("default", Label.LabelStyle.class));
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        menuStage.getViewport().update(width, height, true);
    }

    @Override
    public void render() {

        ScreenUtils.clear(Color.BLACK);
        viewport.apply();

        switch (world.getState()) {
            case MENU:
                menuInput();
                drawMenu();
                break;
            case PLAYING:
                universalInput();

                playingInput();
                drawMaze();
                drawPlayer();
                drawEnemy();
                drawFog();
                drawTime();
                drawOverlay();
                world.updateGame();
                Gdx.input.setInputProcessor(null); // disable ui input during gameplay
                break;
            case PAUSED:
                universalInput();

                menuInput();
                drawPause();
                break;
            case VICTORY:
                universalInput();

                drawVictory();
                break;
            case GAMEOVER:
                universalInput();

                drawLose();
                break;
        }

    }

    /**
     * Draws and updates active overlay messages on screen.
     * Manages a queue of timed overlays, displaying them sequentially.
     * Removes overlays when their display time expires.
     */
    public void drawOverlay() {
        if (!activeOverlays.isEmpty()) {
            TimedOverlay current = activeOverlays.peek(); // peek at the first overlay
            if (current.update(Gdx.graphics.getDeltaTime())) {
                activeOverlays.poll(); // remove it from the queue
            } else {
                current.render(batch);
            }
        }
    }

    /**
     * Adds a timed overlay to the display queue.
     * Part of the I_UI interface implementation.
     *
     * @param timedOverlay the overlay message to display
     */
    @Override
    public void displayUI(TimedOverlay timedOverlay) {
        activeOverlays.add(timedOverlay);
    }

    /**
     * Handles input that works in any game state.
     * Currently handles the R key for restarting the game.
     */
    public void universalInput() {
        if (Gdx.input.isKeyJustPressed(Keys.R)) {
            world = new World("Maze.csv", this);
            activeOverlays.clear();
        }
    }

    /**
     * Handles player input during active gameplay.
     * Processes movement keys (Arrow Keys or WASD based on settings).
     * Also handles SPACE for pausing and R for restarting.
     */
    public void playingInput() {
        if (Gdx.input.isKeyJustPressed(Keys.R)) {
            world = new World("Maze.csv", this);
        }

        if (useWASD) {
            // WASD controls
            if (Gdx.input.isKeyJustPressed(Keys.D)) {
                world.movePlayer(1, 0);
            }
            if (Gdx.input.isKeyJustPressed(Keys.A)) {
                world.movePlayer(-1, 0);
            }
            if (Gdx.input.isKeyJustPressed(Keys.W)) {
                world.movePlayer(0, 1);
            }
            if (Gdx.input.isKeyJustPressed(Keys.S)) {
                world.movePlayer(0, -1);
            }
        } else {
            // Arrow key controls
            if (Gdx.input.isKeyJustPressed(Keys.RIGHT)) {
                world.movePlayer(1, 0);
            }
            if (Gdx.input.isKeyJustPressed(Keys.LEFT)) {
                world.movePlayer(-1, 0);
            }
            if (Gdx.input.isKeyJustPressed(Keys.UP)) {
                world.movePlayer(0, 1);
            }
            if (Gdx.input.isKeyJustPressed(Keys.DOWN)) {
                world.movePlayer(0, -1);
            }
        }

        if (Gdx.input.isKeyJustPressed(Keys.SPACE)) {
            world.setState(State.PAUSED);
        }
    }

    /**
     * Handles input during menu and pause states.
     * SPACE to start/resume, ESC to exit, LEFT/RIGHT arrows to switch control schemes.
     */
    public void menuInput() {
        if (Gdx.input.isKeyJustPressed(Keys.SPACE)) {
            world.setState(State.PLAYING);
        }

        if (Gdx.input.isKeyJustPressed(Keys.ESCAPE)) {
            Gdx.app.exit(); // Exits the game
        }

        // Use left/right arrow keys to switch control scheme
        if (Gdx.input.isKeyJustPressed(Keys.LEFT)) {
            selectArrowKeys();
        }
        if (Gdx.input.isKeyJustPressed(Keys.RIGHT)) {
            selectWASD();
        }
    }

    /**
     * Renders the maze tiles to the screen.
     * Draws each tile's texture scaled to fill the screen based on maze dimensions.
     */
    private void drawMaze() {
        batch.setProjectionMatrix(viewport.getCamera().combined);
        batch.begin();

        Tile[][] maze = world.getTileMap();
        int mazeHeight = world.getMapHeight();
        int mazeWidth = world.getMapWidth();

        // Calculate tile size to fill the screen
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / mazeWidth;
        float tileHeight = screenHeight / mazeHeight;

        for (int row = 0; row < mazeHeight; row++) {
            for (int col = 0; col < mazeWidth; col++) {
                // Draw the tile's texture directly
                batch.draw(maze[row][col].getTexture(), col * tileWidth, row * tileHeight, tileWidth, tileHeight);
            }
        }

        batch.end();

    }

    /**
     * Renders the fog of war overlay on the maze.
     * Uses the visibility map to apply semi-transparent fog textures.
     * Fully visible tiles have no fog, unexplored tiles are fully fogged.
     */
    private void drawFog() {
        float[][] visibilityMap = world.getVisibilityMap();

        int mazeHeight = world.getMapHeight();
        int mazeWidth = world.getMapWidth();

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / mazeWidth;
        float tileHeight = screenHeight / mazeHeight;


        batch.setProjectionMatrix(viewport.getCamera().combined);
        batch.begin();

        for (int y = 0; y < mazeHeight; y++) {
            for (int x = 0; x < mazeWidth; x++) {
                float alpha = visibilityMap[y][x];

                batch.setColor(1f, 1f, 1f, alpha);
                batch.draw(fogTexture, x * tileWidth, y * tileHeight, tileWidth, tileHeight);
            }
        }

        batch.setColor(1f, 1f, 1f, 1f); // reset batch color
        batch.end();
    }

    /**
     * Renders the player character at their current position.
     * Scales the player texture to match maze tile dimensions.
     */
    private void drawPlayer() {
        int mazeHeight = world.getMapHeight();
        int mazeWidth = world.getMapWidth();

        batch.setProjectionMatrix(viewport.getCamera().combined);
        batch.begin();

        // Calculate tile size to match maze tiles
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / mazeWidth;
        float tileHeight = screenHeight / mazeHeight;

        // Draw player as a white square
        Vector2 playerPos = world.getPlayerPos();
        batch.draw(playerTexture,
                playerPos.x * tileWidth,
                playerPos.y * tileHeight,
                tileWidth,
                tileHeight);

        batch.end();
    }

    /**
     * Renders all active enemies to the screen.
     * Iterates through the enemy list and draws each spawned enemy at its position.
     * Scales enemy textures to match maze tile dimensions.
     */
    private void drawEnemy() {
        // Get all enemies from the world
        if (world.getEnemies().isEmpty()) {
            return;
        }

        Tile[][] maze = world.getTileMap();
        batch.setProjectionMatrix(viewport.getCamera().combined);
        batch.begin();

        // Calculate tile size to match maze tiles
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float tileWidth = screenWidth / maze[0].length;
        float tileHeight = screenHeight / maze.length;

        // Draw each enemy at its current position
        for (Enemy enemy : world.getEnemies()) {
            if (enemy.isSpawned()) {
                Vector2 enemyPos = enemy.getPosition();
                batch.draw(enemy.getTexture(),
                        enemyPos.x * tileWidth,
                        enemyPos.y * tileHeight,
                        tileWidth,
                        tileHeight);
            }
        }

        batch.end();
    }

    /**
     * Renders the main menu screen.
     * Updates and draws the menu stage with instructions and control settings.
     * Enables input processing for UI interactions.
     */
    private void drawMenu() {
        Gdx.input.setInputProcessor(menuStage); // Enable button clicks
        menuStage.act(Gdx.graphics.getDeltaTime());
        menuStage.draw();
    }

    /**
     * Renders the pause screen.
     * Displays "GAME PAUSED" text over a full-screen bookshelf background.
     */
    private void drawPause() {
        batch.setProjectionMatrix(viewport.getCamera().combined);

        String text = "GAME PAUSED";

        // Measure the text width and height
        GlyphLayout layout = new GlyphLayout(victoryFont, text);

        // Set font color to white for visibility
        victoryFont.setColor(Color.WHITE);

        // Use viewport's world size (not raw pixels) for consistency
        float textX = (viewport.getWorldWidth() - layout.width) / 2;
        float textY = (viewport.getWorldHeight() + layout.height) / 2;

        batch.begin();

        // Draw bookshelf background to fill entire screen
        batch.draw(bookshelfTexture, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());

        // Draw the pause text on top
        victoryFont.draw(batch, layout, textX, textY);

        batch.end();
    }

    /**
     * Renders the victory screen.
     * Displays "Victory!" in green and the player's final score in white.
     * Uses a gray background color (#ABABAB).
     */
    private void drawVictory() {
        // Fill screen with #ABABAB background
        ScreenUtils.clear(0xAB / 255f, 0xAB / 255f, 0xAB / 255f, 1f);

        batch.setProjectionMatrix(viewport.getCamera().combined);

        // Victory title text
        String victoryText = "Victory!";

        // Score text
        String scoreText = "Your Score Was: " + world.getScore();

        // Event ammount text
        String eventString = "You Triggered " + world.getEventCount() + " Events!";


        // Set font color to GREEN and measure victory text
        victoryFont.setColor(Color.GREEN);
        GlyphLayout victoryLayout = new GlyphLayout(victoryFont, victoryText);

        // Set font color to WHITE and measure score text
        victoryFont.setColor(Color.WHITE);
        GlyphLayout scoreLayout = new GlyphLayout(victoryFont, scoreText);

        GlyphLayout eventLayout = new GlyphLayout(victoryFont, eventString);

        // Calculate positions (victory text above score text)
        float victoryX = (viewport.getWorldWidth() - victoryLayout.width) / 2;
        float scoreX = (viewport.getWorldWidth() - scoreLayout.width) / 2;

        // Center both texts vertically with some spacing between them
        float centerY = viewport.getWorldHeight() / 2;
        float spacing = 20; // Space between the two lines
        float victoryY = centerY + victoryLayout.height + spacing;
        float scoreY = centerY - spacing;
        float eventY = scoreY - scoreLayout.height - spacing;

        batch.begin();

        // Draw "Victory" in green (color already in layout)
        victoryFont.draw(batch, victoryLayout, victoryX, victoryY);

        // Draw score text in white (color already in layout)
        victoryFont.draw(batch, scoreLayout, scoreX, scoreY);

        // Draw event amount text in white (color already in layout)
        victoryFont.draw(batch, eventLayout, scoreX, eventY);

        batch.end();
    }

    /**
     * Renders the game over/lose screen.
     * Displays "YOU LOSE!" in large white Balatro font centered on black background.
     */
    public void drawLose() {
        batch.setProjectionMatrix(viewport.getCamera().combined);

        String text = "YOU LOSE!";

        // Set font color to white for visibility
        victoryFont.setColor(Color.WHITE);

        // Measure the text width and height
        GlyphLayout layout = new GlyphLayout(victoryFont, text);

        // Use viewport's world size (not raw pixels) for consistency
        float textX = (viewport.getWorldWidth() - layout.width) / 2;
        float textY = (viewport.getWorldHeight() + layout.height) / 2;

        batch.begin();
        victoryFont.draw(batch, layout, textX, textY);
        batch.end();
    }

    /**
     * Renders the remaining time display during gameplay.
     * Shows "Time Left: X.X" in lime color at the top-right corner of the screen.
     */
    public void drawTime() {
        // Convert the float to text, e.g., rounding to 1 decimal
        String timeText = "Time Left: " + String.format("%.1f", world.getTime());

        // Measure text size
        GlyphLayout layout = new GlyphLayout(font, timeText);

        // Position in top-right corner
        float x = viewport.getWorldWidth() - layout.width - 10; // 10 units from right
        float y = viewport.getWorldHeight() - 10; // 10 units down from top

        batch.begin();
        font.setColor(Color.LIME);
        font.draw(batch, layout, x, y);
        batch.end();

        font.setColor(Color.WHITE);
    }

    @Override
    public void dispose() {
        batch.dispose();
        shapeRenderer.dispose();

        assetManager.dispose();

        // Dispose UI resources
        menuStage.dispose();
        skin.dispose();

        // Dispose custom fonts
        menuFont.dispose();
        victoryFont.dispose();
    }
}
