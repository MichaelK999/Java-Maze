package io.github.some_example_name;

/**
 * UI rendering contract used by the game's user interface/presentation system.
 *
 * <p>Implementations of this interface are responsible for displaying timed overlays.
 */
public interface I_UI {
    /**
     * Request the UI to display the provided {@link TimedOverlay}.
     *
     * @param timedOverlay the overlay to display; never null
     */
    void displayUI(TimedOverlay timedOverlay);
}
