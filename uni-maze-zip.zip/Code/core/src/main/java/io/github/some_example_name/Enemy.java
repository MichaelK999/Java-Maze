package io.github.some_example_name;

import java.util.LinkedList;
import java.util.Queue;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

import io.github.some_example_name.Tiles.Tile;

public class Enemy {

    private Queue<Vector2> playerTrail;
    private Vector2 enemyPos;
    private Texture enemyTexture;
    private boolean enemySpawned;
    private float enemyMoveTimer;
    private float enemyActivationDelay;

    private static final float ENEMY_MOVE_INTERVAL = 0.5f;
    private static final float ENEMY_ACTIVATION_DELAY = 2.0f;

    private GameAssets assetManager;

    /**
     * Constructs a new Enemy instance.
     * Initializes the player trail queue, enemy position, texture, and movement timers.
     * The enemy starts unspawned at position (-1, -1).
     */
    public Enemy() {
        assetManager = GameAssets.getInstance();

        playerTrail = new LinkedList<>();
        enemyPos = new Vector2(-1, -1);
        enemyTexture = assetManager.get("Sprites/Enemy.png", Texture.class);
        enemySpawned = false;
        enemyMoveTimer = 0f;
        enemyActivationDelay = 0f;
    }

    /**
     * Spawns the enemy at the specified tile location.
     * Can only spawn once - subsequent calls after spawning will have no effect.
     * Resets movement timer and sets a 2-second activation delay before the enemy starts moving.
     * 
     * @param tile the tile where the enemy should spawn
     */
    public void spawn(Tile tile) {
        if (!enemySpawned) {
            enemySpawned = true;
            enemyPos.set(tile.getTilePos());
            enemyMoveTimer = 0f;
            enemyActivationDelay = ENEMY_ACTIVATION_DELAY;
        }
    }

    /**
     * Adds a player position to the enemy's tracking trail.
     * The enemy will follow this trail of breadcrumbs to chase the player.
     * Only adds breadcrumbs if the enemy has been spawned.
     * 
     * @param position the player's current position to add to the trail
     */
    public void addPlayerBreadcrumb(Vector2 position) {
        if (enemySpawned) {
            playerTrail.add(new Vector2(position.x, position.y));
        }
    }

    /**
     * Updates the enemy's state each frame.
     * Handles the activation delay, movement timer, and breadcrumb trail following.
     * Moves the enemy every 0.5 seconds along the player's trail.
     * Checks for collision with the player after moving.
     * 
     * @param playerPos the current position of the player
     * @return true if the enemy collided with the player, false otherwise
     */
    public boolean update(Vector2 playerPos) {
        float delta = Gdx.graphics.getDeltaTime();

        if (!enemySpawned) {
            return false;
        }

        if (enemyActivationDelay > 0) {
            enemyActivationDelay -= delta;
            return false;
        }

        enemyMoveTimer += delta;

        if (enemyMoveTimer >= ENEMY_MOVE_INTERVAL) {
            enemyMoveTimer -= ENEMY_MOVE_INTERVAL;

            if (!playerTrail.isEmpty()) {
                Vector2 nextPosition = playerTrail.poll();
                enemyPos.set(nextPosition);
            }
        }

        return checkCollision(playerPos);
    }

    /**
     * Checks if the enemy has collided with the player.
     * Collision occurs when both the enemy and player occupy the same tile position.
     * 
     * @param playerPos the current position of the player
     * @return true if the enemy and player positions match, false otherwise
     */
    private boolean checkCollision(Vector2 playerPos) {
        if (enemySpawned) {
            if ((int) enemyPos.x == (int) playerPos.x &&
                (int) enemyPos.y == (int) playerPos.y) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the enemy has been spawned.
     * 
     * @return true if the enemy is active in the game, false otherwise
     */
    public boolean isSpawned() {
        return enemySpawned;
    }

    /**
     * Gets the current position of the enemy.
     * 
     * @return a Vector2 containing the enemy's x and y coordinates
     */
    public Vector2 getPosition() {
        return enemyPos;
    }

    /**
     * Gets the texture used to render the enemy.
     * 
     * @return the enemy's Texture object
     */
    public Texture getTexture() {
        return enemyTexture;
    }
}

