package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

/**
 * A short-lived visual overlay that displays a texture for a fixed duration.
 *
 * <p>Use this class to show transient images such as notifications, splash
 * screens, or fade effects. The overlay can be drawn to fill the screen or be
 * centered with a specific size. Optionally the overlay can fade out during the
 * last second of its lifetime. Used in conjunction with a queue in main to manege
 * multiple overlays.
 *
 * Typical usage:
 * <pre>
 * TimedOverlay overlay = new TimedOverlay("Screens/tutorial.png", 3.0f, true, 1.0f);
 * // each frame:
 * overlay.update(delta));
 */
public class TimedOverlay {
    /** The texture to render for the overlay. */
    private Texture texture;

    /** Remaining time (in seconds) before the overlay expires. */
    private float timer;

    /** If true, the overlay will fade out during the final second. */
    private boolean doFade;

    /** If true, the overlay is stretched to fill the entire screen. */
    private boolean fillScreen;

    /** Width to draw the texture when not filling the screen. */
    private float imgWidth;

    /** Height to draw the texture when not filling the screen. */
    private float imgHeight;

    /** Initial alpha (opacity) used when rendering; values are 0.0 (transparent) to 1.0 (opaque). */
    private float initialAlpha;

    /** Reference to the shared GameAssets instance used to obtain textures. */
    private GameAssets assetManager;

    /**
     * Create an overlay that renders a texture at a specified size for a duration.
     *
     * @param filePath path/key used to fetch the texture from {@link GameAssets}
     * @param duration how long (in seconds) the overlay should remain visible
     * @param fade whether the overlay should fade out during the last second
     * @param alpha initial transparency (0.0 to 1.0)
     * @param width width in pixels to draw the texture when not filling the screen
     * @param height height in pixels to draw the texture when not filling the screen
     */
    public TimedOverlay(String filePath, float duration, boolean fade, float alpha, float width, float height) {
        assetManager = GameAssets.getInstance();
        this.texture = assetManager.get(filePath, Texture.class);
        this.timer = duration;
        this.doFade = fade;
        this.fillScreen = false;
        this.imgWidth = width;
        this.imgHeight = height;
        this.initialAlpha = alpha;
    }

    /**
     * Create an overlay that fills the screen using the texture's natural size.
     *
     * @param filePath path/key used to fetch the texture from {@link GameAssets}
     * @param duration how long (in seconds) the overlay should remain visible
     * @param fade whether the overlay should fade out during the last second
     * @param alpha initial transparency (0.0 to 1.0)
     */
    public TimedOverlay(String filePath, float duration, boolean fade, float alpha) {
        assetManager = GameAssets.getInstance();
        this.texture = assetManager.get(filePath, Texture.class);
        this.timer = duration;
        this.doFade = fade;
        this.fillScreen = true;
        this.imgWidth = texture.getWidth();
        this.imgHeight = texture.getHeight();
        this.initialAlpha = alpha;
    }

    /**
     * Update the overlay's internal timer.
     *
     * <p>Call once per frame with the frame's delta time. When the timer reaches
     * zero or below the overlay is considered expired.
     *
     * @param delta time elapsed since last frame (seconds)
     * @return true when the overlay has expired (timer &lt;= 0), false otherwise
     */
    public boolean update(float delta) {
        timer -= delta;
        return timer <= 0;
    }

    /**
     * Render the overlay using the provided SpriteBatch.
     *
     * <p>This method begins and ends the batch internally, and resets the batch's
     * color after drawing. If fading is enabled the overlay will linearly reduce
     * its alpha from {@link #initialAlpha} down to 0 during the last second.
     *
     * @param batch the {@link SpriteBatch} used for drawing
     */
    public void render(SpriteBatch batch) {
        batch.begin();

        float alpha = initialAlpha;
        if (doFade && timer < 1f) {
            alpha = Math.max(0f, timer / 1f * initialAlpha);
        }

        batch.setColor(1f, 1f, 1f, alpha);

        if (this.fillScreen) {
            batch.draw(this.texture, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        } else {
            float drawX = (Gdx.graphics.getWidth() - this.imgWidth) / 2f;
            float drawY = (Gdx.graphics.getHeight() - this.imgHeight) / 2f;
            batch.draw(this.texture, drawX, drawY, this.imgWidth, this.imgHeight);
        }

        batch.setColor(1f, 1f, 1f, 1f); // reset color
        batch.end();
    }
}
