package io.github.some_example_name.Enums;

/**
 * Represents the top-level states the game can be in.
 *
 * <p>Use this enum to manage high-level game flow (menu, gameplay, pauses, and end
 * conditions). Typical usage:
 * <pre>
 *   State current = State.MENU;
 *   if (current == State.PLAYING) { ... }
 * </pre>
 *
 */
public enum State {
    /**
     * Initial game state displayed on startup and after a reset.
     * Typically used to show title screen, options, and to start a new game.
     */
    MENU,

    /**
     * Temporary paused state while the game is running.
     * Usually reachable from {@link #PLAYING} and returns to {@link #PLAYING} when resumed.
     */
    PAUSED,

    /**
     * Active gameplay state. The main game loop runs and player input controls the game.
     */
    PLAYING,

    /**
     * The player has met the victory condition.
     * Used to show victory screen/summary and can be implemented to allow transition to next level.
     */
    VICTORY,

    /**
     * The player has lost or the game has reached a game-over condition.
     * Used to show game-over UI and provide options to restart and return to menu.
     */
    GAMEOVER
}
